-- STEEL/FAIRY AND TYPING CHARTS v1.0.0
--
-- Preset + custom type-chart controls for Gen1Recomp.
-- Content changes are load-time registry changes, so gameplay changes take
-- effect after restarting Gen1Recomp. The options UI itself is synchronized
-- immediately: selecting a preset writes its component options; manually
-- changing any component switches PRESET to CUSTOM.

local MOD_ID = "steel_typing"
local STEEL = "STEEL"
local FAIRY = "FAIRY"

local PRESET_VANILLA = "vanilla"
local PRESET_GEN2 = "gen2"
local PRESET_GEN6 = "gen6"
local PRESET_CUSTOM = "custom"

local FIX_OFF = "off"
local FIX_VANILLA = "vanilla"
local FIX_GEN2 = "gen2"
local FIX_GEN6 = "gen6"

local KEY_PRESET = "preset"
local KEY_STEEL = "steel_type"
local KEY_FAIRY = "fairy_type"
local KEY_GHOST_STEEL = "ghost_vs_steel"
local KEY_GHOST_PSYCHIC = "ghost_vs_psychic"
local KEY_BUG_POISON = "bug_vs_poison"
local KEY_ICE_FIRE = "ice_vs_fire"

local COMPONENT_KEYS = {
  KEY_STEEL,
  KEY_FAIRY,
  KEY_GHOST_STEEL,
  KEY_GHOST_PSYCHIC,
  KEY_BUG_POISON,
  KEY_ICE_FIRE,
}

local COMPONENT_KEY_SET = {}
for _, key in ipairs(COMPONENT_KEYS) do COMPONENT_KEY_SET[key] = true end

local PRESETS = {
  [PRESET_VANILLA] = {
    [KEY_STEEL] = false,
    [KEY_FAIRY] = false,
    [KEY_GHOST_STEEL] = FIX_OFF,
    [KEY_GHOST_PSYCHIC] = FIX_VANILLA,
    [KEY_BUG_POISON] = FIX_VANILLA,
    [KEY_ICE_FIRE] = FIX_VANILLA,
  },
  [PRESET_GEN2] = {
    [KEY_STEEL] = true,
    [KEY_FAIRY] = false,
    [KEY_GHOST_STEEL] = FIX_GEN2,
    [KEY_GHOST_PSYCHIC] = FIX_GEN2,
    [KEY_BUG_POISON] = FIX_GEN2,
    [KEY_ICE_FIRE] = FIX_GEN2,
  },
  [PRESET_GEN6] = {
    [KEY_STEEL] = true,
    [KEY_FAIRY] = true,
    [KEY_GHOST_STEEL] = FIX_GEN6,
    [KEY_GHOST_PSYCHIC] = FIX_GEN2,
    [KEY_BUG_POISON] = FIX_GEN2,
    [KEY_ICE_FIRE] = FIX_GEN2,
  },
}

-- Gen1Recomp matchup multipliers are x10:
--   0 = immune, 5 = half damage, 10 = neutral, 20 = double damage.
local STEEL_COMMON = {
  -- Existing attack types -> Steel defender
  { "NORMAL>STEEL",        5 },
  { "FIGHTING>STEEL",     20 },
  { "FLYING>STEEL",        5 },
  { "POISON>STEEL",        0 },
  { "GROUND>STEEL",       20 },
  { "ROCK>STEEL",          5 },
  { "BUG>STEEL",           5 },
  { "FIRE>STEEL",         20 },
  { "GRASS>STEEL",         5 },
  { "PSYCHIC_TYPE>STEEL",  5 },
  { "ICE>STEEL",           5 },
  { "DRAGON>STEEL",        5 },

  -- Steel attacker -> existing defender types
  { "STEEL>ROCK",         20 },
  { "STEEL>FIRE",          5 },
  { "STEEL>WATER",         5 },
  { "STEEL>ELECTRIC",      5 },
  { "STEEL>ICE",          20 },
  { "STEEL>STEEL",         5 },
}

local FAIRY_BASE = {
  -- Existing Gen I attack types -> Fairy defender
  { "FIGHTING>FAIRY", 5 },
  { "POISON>FAIRY",  20 },
  { "BUG>FAIRY",      5 },
  { "DRAGON>FAIRY",   0 },

  -- Fairy attacker -> existing Gen I defender types
  { "FAIRY>FIGHTING", 20 },
  { "FAIRY>POISON",    5 },
  { "FAIRY>FIRE",      5 },
  { "FAIRY>DRAGON",   20 },
}

local FAIRY_STEEL_CROSS = {
  { "STEEL>FAIRY", 20 },
  { "FAIRY>STEEL",  5 },
}

local SPECIES = {
  MAGNEMITE = { vanilla = "ELECTRIC", steel = { "ELECTRIC", STEEL } },
  MAGNETON  = { vanilla = "ELECTRIC", steel = { "ELECTRIC", STEEL } },
  CLEFAIRY  = { vanilla = "NORMAL", fairy = { FAIRY } },
  CLEFABLE  = { vanilla = "NORMAL", fairy = { FAIRY } },
  JIGGLYPUFF = { vanilla = "NORMAL", fairy = { "NORMAL", FAIRY } },
  WIGGLYTUFF = { vanilla = "NORMAL", fairy = { "NORMAL", FAIRY } },
  MR_MIME = { vanilla = "PSYCHIC_TYPE", fairy = { "PSYCHIC_TYPE", FAIRY } },
}

local STEEL_SPECIES = { "MAGNEMITE", "MAGNETON" }
local FAIRY_SPECIES = { "CLEFAIRY", "CLEFABLE", "JIGGLYPUFF", "WIGGLYTUFF", "MR_MIME" }

local function sameTyping(types, expected)
  if type(types) ~= "table" or type(expected) ~= "table" then return false end
  if #types ~= #expected then return false end
  for i = 1, #expected do
    if types[i] ~= expected[i] then return false end
  end
  return true
end

-- Vanilla Gen I may represent a monotype once or duplicate it across both
-- type slots. Accept either form while respecting typings owned by other mods.
local function isVanillaMonotype(types, expectedType)
  if type(types) ~= "table" or #types == 0 then return false end
  for _, typeId in ipairs(types) do
    if typeId ~= expectedType then return false end
  end
  return true
end

local function typingText(types)
  if type(types) ~= "table" then return tostring(types) end
  return table.concat(types, "/")
end

local function registerRows(mod, rows)
  for _, row in ipairs(rows) do
    mod.content.type_chart:register(row[1], { multiplier = row[2] })
  end
end

-- Existing Gen I matchup rows are patched. Neutral matchups may have no row,
-- so register them when a later-generation rule needs an explicit value.
local function setMatchup(mod, id, multiplier)
  if mod.content.type_chart:get(id) ~= nil then
    mod.content.type_chart:patch(id, { multiplier = multiplier })
  else
    mod.content.type_chart:register(id, { multiplier = multiplier })
  end
end

local function patchSpecies(mod, speciesId, target)
  local spec = SPECIES[speciesId]
  local mon = mod.content.pokemon:get(speciesId)
  if not mon then
    mod.log:warn("%s is not present in the merged Pokemon registry; skipped", speciesId)
    return "skipped"
  end
  if sameTyping(mon.types, target) then
    return "already"
  end
  if not isVanillaMonotype(mon.types, spec.vanilla) then
    mod.log:warn("%s has typing %s, not vanilla %s; another mod may own its typing, skipped",
                 speciesId, typingText(mon.types), spec.vanilla)
    return "skipped"
  end
  mod.content.pokemon:patch(speciesId, { types = target })
  return "applied"
end

-- The public mod.options API intentionally exposes define/get only. The Mod
-- Manager owns writes through ManagerState:setOption. To make PRESET behave as
-- a true aggregate control, narrowly wrap that writer for this mod only.
local function installPresetOptionSync(mod)
  local ok, ManagerState = pcall(require, "src.mods.ManagerState")
  if not ok or type(ManagerState) ~= "table" or type(ManagerState.setOption) ~= "function" then
    mod.log:warn("STEEL/FAIRY AND TYPING CHARTS could not install PRESET synchronization; component options still work")
    return false
  end

  -- One process can construct more than one Loader/Game during restart flows.
  -- Patch the class once, not once per mod load.
  if ManagerState.__typingChartsPresetSyncInstalled then return true end

  local originalSetOption = ManagerState.setOption
  local syncing = false

  -- Resolve the effective option value exactly as the Mod Manager does:
  -- persisted value first, otherwise the schema default. This lets normal
  -- "Reset defaults" writes keep their preset instead of being mistaken for
  -- a manual customization.
  local function effectiveOption(self, key)
    local loader = self and self.game and self.game.mods
    if not loader then return nil end

    local bucket = loader.modOptions and loader.modOptions[MOD_ID]
    if bucket and bucket[key] ~= nil then return bucket[key] end

    local schema = loader.optionSchemas and loader.optionSchemas[MOD_ID]
    if type(schema) == "table" then
      for _, row in ipairs(schema) do
        if row.key == key then return row.default end
      end
    end
    return nil
  end

  local function matchesPreset(self, presetId)
    local expected = PRESETS[presetId]
    if not expected then return false end
    for _, componentKey in ipairs(COMPONENT_KEYS) do
      if effectiveOption(self, componentKey) ~= expected[componentKey] then
        return false
      end
    end
    return true
  end

  ManagerState.setOption = function(self, modId, key, value)
    if modId ~= MOD_ID or syncing then
      return originalSetOption(self, modId, key, value)
    end

    if key == KEY_PRESET then
      local result = originalSetOption(self, modId, key, value)
      local values = PRESETS[value]
      if values then
        syncing = true
        for _, componentKey in ipairs(COMPONENT_KEYS) do
          originalSetOption(self, modId, componentKey, values[componentKey])
        end
        syncing = false
      end
      -- CUSTOM deliberately preserves the current component values.
      return result
    end

    if COMPONENT_KEY_SET[key] then
      local result = originalSetOption(self, modId, key, value)
      local currentPreset = effectiveOption(self, KEY_PRESET)

      -- A real component edit that diverges from the active preset becomes
      -- CUSTOM. Re-writing the same preset values (for example the Mod
      -- Manager's Reset Defaults loop) keeps the preset intact. Once already
      -- CUSTOM, component edits remain CUSTOM even if values happen to match
      -- a built-in preset again.
      if currentPreset == PRESET_CUSTOM or not matchesPreset(self, currentPreset) then
        syncing = true
        originalSetOption(self, modId, KEY_PRESET, PRESET_CUSTOM)
        syncing = false
      end
      return result
    end

    return originalSetOption(self, modId, key, value)
  end

  ManagerState.__typingChartsPresetSyncInstalled = true
  ManagerState.__typingChartsPresetSyncOriginal = originalSetOption
  return true
end

local function legacyPreset(mod)
  -- Earlier development builds stored a single option named "era". Reading an undefined key
  -- still returns a persisted value, so use it only as the default for the new
  -- schema. This preserves existing VANILLA / GEN II / GEN VI installations.
  local old = mod.options:get("era")
  if old == PRESET_VANILLA or old == PRESET_GEN2 or old == PRESET_GEN6 then
    return old
  end
  return PRESET_GEN6
end

return function(mod)
  local defaultPreset = legacyPreset(mod)
  local defaults = PRESETS[defaultPreset] or PRESETS[PRESET_GEN6]

  mod.options:define({
    {
      key = KEY_PRESET,
      label = "PRESET",
      type = "choice",
      default = defaultPreset,
      choices = {
        { "VANILLA", PRESET_VANILLA },
        { "GEN II (STEEL)", PRESET_GEN2 },
        { "GEN VI (STEEL+FAIRY)", PRESET_GEN6 },
        { "CUSTOM", PRESET_CUSTOM },
      },
    },
    {
      key = KEY_STEEL,
      label = "STEEL TYPE",
      type = "toggle",
      default = defaults[KEY_STEEL],
    },
    {
      key = KEY_FAIRY,
      label = "FAIRY TYPE",
      type = "toggle",
      default = defaults[KEY_FAIRY],
    },
    {
      key = KEY_GHOST_STEEL,
      label = "GHOST VS STEEL FIX",
      type = "choice",
      default = defaults[KEY_GHOST_STEEL],
      choices = {
        { "OFF", FIX_OFF },
        { "GEN II", FIX_GEN2 },
        { "GEN VI", FIX_GEN6 },
      },
    },
    {
      key = KEY_GHOST_PSYCHIC,
      label = "GHOST VS PSYCHIC FIX",
      type = "choice",
      default = defaults[KEY_GHOST_PSYCHIC],
      choices = {
        { "Vanilla", FIX_VANILLA },
        { "GEN II", FIX_GEN2 },
      },
    },
    {
      key = KEY_BUG_POISON,
      label = "BUG VS POISON FIX",
      type = "choice",
      default = defaults[KEY_BUG_POISON],
      choices = {
        { "Vanilla", FIX_VANILLA },
        { "GEN II", FIX_GEN2 },
      },
    },
    {
      key = KEY_ICE_FIRE,
      label = "ICE VS FIRE FIX",
      type = "choice",
      default = defaults[KEY_ICE_FIRE],
      choices = {
        { "Vanilla", FIX_VANILLA },
        { "GEN II", FIX_GEN2 },
      },
    },
  })

  installPresetOptionSync(mod)

  local config = {
    preset = tostring(mod.options:get(KEY_PRESET) or defaultPreset),
    steel = mod.options:get(KEY_STEEL) and true or false,
    fairy = mod.options:get(KEY_FAIRY) and true or false,
    ghostSteel = tostring(mod.options:get(KEY_GHOST_STEEL) or FIX_OFF),
    ghostPsychic = tostring(mod.options:get(KEY_GHOST_PSYCHIC) or FIX_VANILLA),
    bugPoison = tostring(mod.options:get(KEY_BUG_POISON) or FIX_VANILLA),
    iceFire = tostring(mod.options:get(KEY_ICE_FIRE) or FIX_VANILLA),
  }

  -- Independent historical fixes.
  if config.ghostPsychic == FIX_GEN2 then
    setMatchup(mod, "GHOST>PSYCHIC_TYPE", 20)
  end

  if config.bugPoison == FIX_GEN2 then
    setMatchup(mod, "BUG>POISON", 5)
    -- Gen II simultaneously changed the reciprocal Poison -> Bug relation
    -- from 2x to neutral. The requested BUG VS POISON switch owns this paired
    -- historical correction so the intended Gen II behavior is preserved.
    setMatchup(mod, "POISON>BUG", 10)
  end

  if config.iceFire == FIX_GEN2 then
    setMatchup(mod, "ICE>FIRE", 5)
  end

  -- Custom types and their Pokemon typings.
  local applied, already, skipped = 0, 0, 0
  local function count(result)
    if result == "applied" then applied = applied + 1
    elseif result == "already" then already = already + 1
    elseif result == "skipped" then skipped = skipped + 1 end
  end

  if config.steel then
    mod.content.type_chart:register(STEEL, {
      name = "STEEL",
      category = "physical",
    })
    registerRows(mod, STEEL_COMMON)

    if config.ghostSteel == FIX_GEN2 then
      setMatchup(mod, "GHOST>STEEL", 5)
    elseif config.ghostSteel == FIX_GEN6 then
      -- Explicit neutral lets GEN VI override an earlier Ghost resistance
      -- supplied by another content patch loaded before this mod.
      setMatchup(mod, "GHOST>STEEL", 10)
    end

    for _, speciesId in ipairs(STEEL_SPECIES) do
      count(patchSpecies(mod, speciesId, SPECIES[speciesId].steel))
    end
  end

  if config.fairy then
    mod.content.type_chart:register(FAIRY, {
      name = "FAIRY",
      category = "special",
    })
    registerRows(mod, FAIRY_BASE)
    if config.steel then registerRows(mod, FAIRY_STEEL_CROSS) end

    for _, speciesId in ipairs(FAIRY_SPECIES) do
      count(patchSpecies(mod, speciesId, SPECIES[speciesId].fairy))
    end
  end

  mod.log:info(
    "STEEL/FAIRY AND TYPING CHARTS: preset=%s steel=%s fairy=%s ghost/steel=%s ghost/psychic=%s bug/poison=%s ice/fire=%s; %d species patched, %d already correct, %d skipped",
    config.preset, tostring(config.steel), tostring(config.fairy),
    config.ghostSteel, config.ghostPsychic, config.bugPoison, config.iceFire,
    applied, already, skipped
  )

  mod.exports.config = config
  mod.exports.presets = PRESETS
  mod.exports.typeIds = { steel = STEEL, fairy = FAIRY }
  mod.exports.species = SPECIES
end

# STEEL/FAIRY AND TYPING CHARTS v1.0.0

A configurable type-chart modernization mod for **Gen1Recomp**.

The internal mod ID is `steel_typing`.

## Options

All gameplay changes are load-time content changes. **ANY CHANGES REQUIRE SAVE AND RESTART.**

### PRESET

- **VANILLA**
- **GEN II (STEEL)**
- **GEN VI (STEEL+FAIRY)**
- **CUSTOM**

Selecting a non-CUSTOM preset immediately updates all component options below. Manually changing **any** component option immediately changes PRESET to **CUSTOM**.

| Option | VANILLA | GEN II (STEEL) | GEN VI (STEEL+FAIRY) |
|---|---|---|---|
| STEEL TYPE | OFF | ON | ON |
| FAIRY TYPE | OFF | OFF | ON |
| GHOST VS STEEL FIX | OFF | GEN II | GEN VI |
| GHOST VS PSYCHIC FIX | Vanilla | GEN II | GEN II |
| BUG VS POISON FIX | Vanilla | GEN II | GEN II |
| ICE VS FIRE FIX | Vanilla | GEN II | GEN II |

**Default preset: GEN VI (STEEL+FAIRY)**. A legacy `era` setting, if present from a development build, is still honored for compatibility.

### CUSTOM behavior

CUSTOM does not impose a separate chart. It means the six component settings are used exactly as selected.

- **STEEL TYPE: ON/OFF** — registers Steel and changes Magnemite/Magneton to Electric/Steel when ON.
- **FAIRY TYPE: ON/OFF** — registers Fairy and applies the requested Fairy-era Kanto typings when ON.
- **GHOST VS STEEL FIX: OFF / GEN II / GEN VI**
  - OFF: STEEL/FAIRY AND TYPING CHARTS does not add a Ghost -> Steel relationship.
  - GEN II: Ghost -> Steel = 1/2x.
  - GEN VI: Ghost -> Steel = 1x (explicit neutral).
- **GHOST VS PSYCHIC FIX: Vanilla / GEN II**
  - Vanilla: leaves the Gen I 0x relationship untouched.
  - GEN II: Ghost -> Psychic = 2x.
- **BUG VS POISON FIX: Vanilla / GEN II**
  - Vanilla: leaves the Gen I Bug/Poison relationships untouched.
  - GEN II: Bug -> Poison = 1/2x and the paired Gen II correction Poison -> Bug = 1x.
- **ICE VS FIRE FIX: Vanilla / GEN II**
  - Vanilla: leaves Ice -> Fire neutral.
  - GEN II: Ice -> Fire = 1/2x.

## Steel

When STEEL TYPE is ON:

### Pokemon
- Magnemite: Electric -> Electric/Steel
- Magneton: Electric -> Electric/Steel

### Base Steel chart
- Weak to: Fire, Fighting, Ground
- Resists: Normal, Grass, Ice, Flying, Psychic, Bug, Rock, Dragon, Steel
- Immune to: Poison
- Steel attacks are super effective against Ice and Rock.
- Steel attacks are not very effective against Fire, Water, Electric, and Steel.

Ghost -> Steel is intentionally controlled separately by **GHOST VS STEEL FIX**.

## Fairy

When FAIRY TYPE is ON:

### Pokemon
- Clefairy: Normal -> Fairy
- Clefable: Normal -> Fairy
- Jigglypuff: Normal -> Normal/Fairy
- Wigglytuff: Normal -> Normal/Fairy
- Mr. Mime: Psychic -> Psychic/Fairy

### Fairy chart
- Weak to: Poison (and Steel when Steel is enabled)
- Resists: Fighting, Bug
- Immune to: Dragon
- Fairy attacks are super effective against Fighting and Dragon.
- Fairy attacks are not very effective against Fire, Poison (and Steel when Steel is enabled).

Dark remains outside the scope of this release.

## PRESET synchronization implementation

Gen1Recomp's public `mod.options` API exposes `define` and `get`; the Mod Manager is the writer and emits `mod.options_changed` after writes. STEEL/FAIRY AND TYPING CHARTS therefore uses a very small `engine_internals` integration that wraps **only** `ManagerState:setOption` calls for mod ID `steel_typing`:

- changing PRESET cascades the six component values;
- changing any component sets PRESET to CUSTOM;
- writes for every other mod pass through unchanged.

The type chart itself still uses the official API 2 `type_chart` and `pokemon` registries. No battle logic is monkey-patched.

## Compatibility

Species are only retyped if they still have their vanilla Generation I monotype. If another mod already owns an affected Pokemon's typing, STEEL/FAIRY AND TYPING CHARTS skips that species.

Because this changes battle-affecting content, both players should use the same configuration in link/online battles.

# Changelog

## 1.0.0 - 2026-08-08

### First public release
- Added PRESET choices: VANILLA, GEN II (STEEL), GEN VI (STEEL+FAIRY), CUSTOM.
- Added independent Steel and Fairy type toggles.
- Added Ghost vs Steel, Ghost vs Psychic, Bug vs Poison, and Ice vs Fire matchup controls.
- Added automatic PRESET synchronization; changing any component manually switches PRESET to CUSTOM.
- Added Steel typing for Magnemite and Magneton.
- Added Fairy typings for Clefairy, Clefable, Jigglypuff, Wigglytuff, and Mr. Mime.
- Added Gen II and Gen VI type-chart behavior for the supported fixes.
- Added prominent warning: ANY CHANGES REQUIRE SAVE AND RESTART.

-- Standalone contract tests for STEEL/FAIRY AND TYPING CHARTS v1.0.0.
-- Run from the mod directory: lua tests/typing_charts_test.lua

local function deepcopy(v)
  if type(v) ~= "table" then return v end
  local out = {}
  for k, x in pairs(v) do out[k] = deepcopy(x) end
  return out
end

local Registry = {}
Registry.__index = Registry
function Registry.new(seed) return setmetatable({ data = deepcopy(seed or {}) }, Registry) end
function Registry:get(id) return self.data[id] end
function Registry:register(id, value)
  assert(self.data[id] == nil, "duplicate registry id: " .. id)
  self.data[id] = deepcopy(value)
end
function Registry:patch(id, patch)
  assert(self.data[id] ~= nil, "missing registry id: " .. id)
  local record = deepcopy(self.data[id])
  for k, v in pairs(patch) do record[k] = deepcopy(v) end
  self.data[id] = record
end

local VANILLA_POKEMON = {
  MAGNEMITE = { types = { "ELECTRIC" } },
  MAGNETON = { types = { "ELECTRIC", "ELECTRIC" } },
  CLEFAIRY = { types = { "NORMAL" } },
  CLEFABLE = { types = { "NORMAL", "NORMAL" } },
  JIGGLYPUFF = { types = { "NORMAL" } },
  WIGGLYTUFF = { types = { "NORMAL", "NORMAL" } },
  MR_MIME = { types = { "PSYCHIC_TYPE", "PSYCHIC_TYPE" } },
}
local VANILLA_TYPE_CHART = {
  ["GHOST>PSYCHIC_TYPE"] = { multiplier = 0 },
  ["BUG>POISON"] = { multiplier = 20 },
  ["POISON>BUG"] = { multiplier = 20 },
}

local ManagerState = {}
function ManagerState:setOption(modId, key, value)
  self.values[modId] = self.values[modId] or {}
  self.values[modId][key] = value
  if self.game and self.game.mods then
    self.game.mods.modOptions = self.game.mods.modOptions or {}
    self.game.mods.modOptions[modId] = self.values[modId]
  end
end
package.preload["src.mods.ManagerState"] = function() return ManagerState end

local function makeMod(values)
  local defined
  values = deepcopy(values or {})
  local mod = {
    content = {
      type_chart = Registry.new(VANILLA_TYPE_CHART),
      pokemon = Registry.new(VANILLA_POKEMON),
    },
    options = {
      define = function(_, rows) defined = rows end,
      get = function(_, key)
        if values[key] ~= nil then return values[key] end
        for _, row in ipairs(defined or {}) do
          if row.key == key then return row.default end
        end
        return nil
      end,
    },
    log = { info = function() end, warn = function() end },
    exports = {},
  }
  return mod, function() return defined end
end

local function run(values)
  -- Reset the one-process sync guard between isolated test cases.
  if ManagerState.__typingChartsPresetSyncOriginal then
    ManagerState.setOption = ManagerState.__typingChartsPresetSyncOriginal
  end
  ManagerState.__typingChartsPresetSyncInstalled = nil
  ManagerState.__typingChartsPresetSyncOriginal = nil

  local mod, getDefined = makeMod(values)
  local chunk = assert(loadfile("main.lua"))
  chunk()(mod)
  return mod, assert(getDefined())
end

local function assertTyping(mod, id, expected)
  local types = assert(mod.content.pokemon:get(id)).types
  assert(#types == #expected, id .. " type count")
  for i = 1, #expected do assert(types[i] == expected[i], id .. " type " .. i) end
end
local function assertMatchup(mod, id, multiplier)
  local row = assert(mod.content.type_chart:get(id), "missing " .. id)
  assert(row.multiplier == multiplier, id .. " multiplier")
end

-- Preset schema and GEN VI defaults.
do
  local mod, rows = run({})
  assert(rows[1].key == "preset" and rows[1].default == "gen6")
  assert(rows[2].key == "steel_type" and rows[2].default == true)
  assert(rows[3].key == "fairy_type" and rows[3].default == true)
  assertMatchup(mod, "GHOST>PSYCHIC_TYPE", 20)
  assertMatchup(mod, "BUG>POISON", 5)
  assertMatchup(mod, "POISON>BUG", 10)
  assertMatchup(mod, "ICE>FIRE", 5)
  assertMatchup(mod, "GHOST>STEEL", 10)
  assertTyping(mod, "MAGNEMITE", { "ELECTRIC", "STEEL" })
  assertTyping(mod, "CLEFAIRY", { "FAIRY" })
end

-- Legacy development-build era defaults are preserved.
do
  local mod, rows = run({ era = "gen2" })
  assert(rows[1].default == "gen2")
  assert(rows[2].default == true)
  assert(rows[3].default == false)
  assert(mod.content.type_chart:get("FAIRY") == nil)
  assertMatchup(mod, "GHOST>STEEL", 5)
end

-- Explicit vanilla components apply no custom content.
do
  local mod = run({
    preset = "vanilla", steel_type = false, fairy_type = false,
    ghost_vs_steel = "off", ghost_vs_psychic = "vanilla",
    bug_vs_poison = "vanilla", ice_vs_fire = "vanilla",
  })
  assert(mod.content.type_chart:get("STEEL") == nil)
  assert(mod.content.type_chart:get("FAIRY") == nil)
  assertMatchup(mod, "GHOST>PSYCHIC_TYPE", 0)
  assertMatchup(mod, "BUG>POISON", 20)
  assertMatchup(mod, "POISON>BUG", 20)
  assert(mod.content.type_chart:get("ICE>FIRE") == nil)
  assertTyping(mod, "MAGNEMITE", { "ELECTRIC" })
  assertTyping(mod, "CLEFAIRY", { "NORMAL" })
end

-- A true custom mix works independently.
do
  local mod = run({
    preset = "custom", steel_type = false, fairy_type = true,
    ghost_vs_steel = "gen2", ghost_vs_psychic = "gen2",
    bug_vs_poison = "vanilla", ice_vs_fire = "vanilla",
  })
  assert(mod.content.type_chart:get("STEEL") == nil)
  assert(mod.content.type_chart:get("FAIRY") ~= nil)
  assert(mod.content.type_chart:get("STEEL>FAIRY") == nil)
  assertMatchup(mod, "GHOST>PSYCHIC_TYPE", 20)
  assertMatchup(mod, "BUG>POISON", 20)
  assertTyping(mod, "MAGNEMITE", { "ELECTRIC" })
  assertTyping(mod, "MR_MIME", { "PSYCHIC_TYPE", "FAIRY" })
end

-- UI writer synchronization: preset cascades; manual edit => CUSTOM.
do
  local _, rows = run({})
  local state = setmetatable({
    values = {},
    game = { mods = { modOptions = {}, optionSchemas = { steel_typing = rows } } },
  }, { __index = ManagerState })
  state:setOption("other_mod", "x", 1)
  assert(state.values.other_mod.x == 1)

  state:setOption("steel_typing", "preset", "gen2")
  local t = state.values.steel_typing
  assert(t.preset == "gen2")
  assert(t.steel_type == true and t.fairy_type == false)
  assert(t.ghost_vs_steel == "gen2")
  assert(t.ghost_vs_psychic == "gen2")
  assert(t.bug_vs_poison == "gen2")
  assert(t.ice_vs_fire == "gen2")

  state:setOption("steel_typing", "fairy_type", true)
  assert(t.fairy_type == true)
  assert(t.preset == "custom")

  state:setOption("steel_typing", "preset", "custom")
  assert(t.preset == "custom" and t.fairy_type == true)
end

-- Re-writing the active preset values (as Reset Defaults does) must not turn
-- PRESET into CUSTOM.
do
  local _, rows = run({})
  local state = setmetatable({
    values = {},
    game = { mods = { modOptions = {}, optionSchemas = { steel_typing = rows } } },
  }, { __index = ManagerState })

  state:setOption("steel_typing", "preset", "gen6")
  state:setOption("steel_typing", "steel_type", true)
  state:setOption("steel_typing", "fairy_type", true)
  state:setOption("steel_typing", "ghost_vs_steel", "gen6")
  state:setOption("steel_typing", "ghost_vs_psychic", "gen2")
  state:setOption("steel_typing", "bug_vs_poison", "gen2")
  state:setOption("steel_typing", "ice_vs_fire", "gen2")
  assert(state.values.steel_typing.preset == "gen6")
end

print("STEEL/FAIRY AND TYPING CHARTS v1.0.0 contract tests: PASS")
